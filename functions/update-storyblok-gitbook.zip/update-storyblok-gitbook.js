import querystring from "querystring";
const StoryblokClient = require('storyblok-js-client')
const { STORYBLOCK_MANAGEMENT_API_OAUTH_TOKEN } = process.env;

exports.handler = async (event, context) => {
  if (event.httpMethod !== "POST") {

// Initialize the client with the oauth token
    const Storyblok = new StoryblokClient({
        oauthToken: STORYBLOCK_MANAGEMENT_API_OAUTH_TOKEN
    })

    return {
      statusCode: 405,
      body: "Method not allowed"
    };
  }

  return {
    statusCode: 200,
    body: `Hello World`
  };
};
